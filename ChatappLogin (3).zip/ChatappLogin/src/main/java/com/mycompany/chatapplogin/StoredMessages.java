/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapplogin;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Student
 */
public class StoredMessages {
 
    public static final String SENT = "Sent";
    public static final String STORED = "Stored";
    public static final String DISREGARD = "Disregard";
 
    private static final ArrayList<String> sentMessages = new ArrayList<>();
    private static final ArrayList<String> disregardedMessages = new ArrayList<>();
    private static final ArrayList<String> storedMessages = new ArrayList<>();
 
    private static final ArrayList<String> messageIDs = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> recipients = new ArrayList<>();
    private static final ArrayList<String> messageTexts = new ArrayList<>();
    private static final ArrayList<String> messageFlags = new ArrayList<>();
 
    private static Path storageFile = Paths.get("messages.json");
 
    // Adding a message to the parallel arrays and to the array for its flag.
    public static void addMessage(String id, String hash, String recipient, String text, String flag) {
        messageIDs.add(id);
        messageHashes.add(hash);
        recipients.add(recipient);
        messageTexts.add(text);
        messageFlags.add(flag);
        categoryArray(flag).add(text);
    }
 
    public static List<String> getSentMessages() {
        return new ArrayList<>(sentMessages);
    }
 
    public static List<String> getDisregardedMessages() {
        return new ArrayList<>(disregardedMessages);
    }
 
    public static List<String> getStoredMessages() {
        return new ArrayList<>(storedMessages);
    }
 
    public static List<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }
 
    public static List<String> getMessageIDs() {
        return new ArrayList<>(messageIDs);
    }
 
    public static int totalSent() {
        return sentMessages.size();
    }
 
    // Empties the arrays in memory (the JSON file is not touched).
    public static void clear() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageIDs.clear();
        messageHashes.clear();
        recipients.clear();
        messageTexts.clear();
        messageFlags.clear();
    }
 
    public static void setStorageFile(Path file) {
        storageFile = file;
    }
 
    // Stored Messages 
 
    // a. The sender and recipient of every stored message.
    public static String displayStoredSenderAndRecipient(String sender) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageFlags.get(i).equals(STORED)) {
                sb.append("Sender: ").append(sender).append(" | Recipient: ").append(recipients.get(i)).append("\n");
            }
        }
        return sb.length() == 0 ? "There are no stored messages." : sb.toString().trim();
    }
 
    // b. The longest stored message.
    public static String longestStoredMessage() {
        String longest = "";
        for (String text : storedMessages) {
            if (text.length() > longest.length()) {
                longest = text;
            }
        }
        return longest.isEmpty() ? "There are no stored messages." : longest;
    }
 
    // c. Search by message ID: showing the recipient and the message.
    public static String searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                return "Recipient: " + recipients.get(i) + ", Message: " + messageTexts.get(i);
            }
        }
        return "Message ID not found.";
    }
 
    // d. All messages sent or stored for one recipient.
    public static List<String> searchByRecipient(String recipient) {
        List<String> found = new ArrayList<>();
        for (int i = 0; i < recipients.size(); i++) {
            boolean kept = messageFlags.get(i).equals(SENT) || messageFlags.get(i).equals(STORED);
            if (kept && recipients.get(i).equals(recipient)) {
                found.add(messageTexts.get(i));
            }
        }
        return found;
    }
 
    // e. Delete a message using its message hash.
    public static String deleteByHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equalsIgnoreCase(hash.trim())) {
                String text = messageTexts.get(i);
                String flag = messageFlags.get(i);
                categoryArray(flag).remove(text);
                messageIDs.remove(i);
                messageHashes.remove(i);
                recipients.remove(i);
                messageTexts.remove(i);
                messageFlags.remove(i);
                if (flag.equals(STORED)) {
                    saveStoredMessages();
                }
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }
 
    // f. Report with the full details of the messages that carry the given flag.
    public static String report(String flag) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageFlags.get(i).equals(flag)) {
                sb.append("Message ID: ").append(messageIDs.get(i)).append("\n")
                  .append("Message Hash: ").append(messageHashes.get(i)).append("\n")
                  .append("Recipient: ").append(recipients.get(i)).append("\n")
                  .append("Message: ").append(messageTexts.get(i)).append("\n\n");
            }
        }
        return sb.toString().trim();
    }
 
    // JSON file
 
    // Writes every stored message to the JSON file as an array of objects.
    public static boolean saveStoredMessages() {
        StringBuilder json = new StringBuilder("[\n");
        boolean first = true;
        for (int i = 0; i < messageIDs.size(); i++) {
            if (!messageFlags.get(i).equals(STORED)) {
                continue;
            }
            if (!first) {
                json.append(",\n");
            }
            first = false;
            json.append("  {\n")
                .append("    \"messageID\": \"").append(escape(messageIDs.get(i))).append("\",\n")
                .append("    \"messageHash\": \"").append(escape(messageHashes.get(i))).append("\",\n")
                .append("    \"recipient\": \"").append(escape(recipients.get(i))).append("\",\n")
                .append("    \"message\": \"").append(escape(messageTexts.get(i))).append("\"\n")
                .append("  }");
        }
        json.append("\n]\n");
        try {
            Files.write(storageFile, json.toString().getBytes(StandardCharsets.UTF_8));
            return true;
        } catch (IOException e) {
            System.out.println("Could not write the JSON file: " + e.getMessage());
            return false;
        }
    }
 
    public static int loadStoredMessages() {
        if (!Files.exists(storageFile)) {
            return 0;
        }
        String json;
        try {
            json = new String(Files.readAllBytes(storageFile), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Could not read the JSON file: " + e.getMessage());
            return 0;
        }
        int loaded = 0;
        for (Map<String, String> entry : parseJson(json)) {
            String id = entry.get("messageID");
            if (id != null && !messageIDs.contains(id)) {
                addMessage(id, entry.get("messageHash"), entry.get("recipient"), entry.get("message"), STORED);
                loaded++;
            }
        }
        return loaded;
    }
 
 
    private static ArrayList<String> categoryArray(String flag) {
        if (flag.equals(SENT)) {
            return sentMessages;
        } else if (flag.equals(STORED)) {
            return storedMessages;
        }
        return disregardedMessages;
    }
 
    // Reads an array of flat JSON objects whose values are all strings.
    private static List<Map<String, String>> parseJson(String json) {
        List<Map<String, String>> objects = new ArrayList<>();
        int i = 0;
        while (i < json.length()) {
            if (json.charAt(i) == '{') {
                Map<String, String> object = new HashMap<>();
                i++;
                while (i < json.length() && json.charAt(i) != '}') {
                    if (json.charAt(i) == '"') {
                        int[] end = new int[1];
                        String key = readString(json, i, end);
                        i = end[0];
                        while (i < json.length() && json.charAt(i) != '"') {
                            i++;
                        }
                        String value = readString(json, i, end);
                        i = end[0];
                        object.put(key, value);
                    } else {
                        i++;
                    }
                }
                objects.add(object);
            }
            i++;
        }
        return objects;
    }
 
    // Reads one quoted JSON string starting at index start; end[0] receives the index after it.
    private static String readString(String s, int start, int[] end) {
        StringBuilder sb = new StringBuilder();
        int i = start + 1;
        while (i < s.length() && s.charAt(i) != '"') {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char next = s.charAt(++i);
                switch (next) {
                    case 'n': sb.append('\n'); break;
                    case 'r': sb.append('\r'); break;
                    case 't': sb.append('\t'); break;
                    case 'u':
                        sb.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16));
                        i += 4;
                        break;
                    default: sb.append(next);   
                }
            } else {
                sb.append(c);
            }
            i++;
        }
        end[0] = i + 1;
        return sb.toString();
    }
 
    // Escapes text so it is valid inside a JSON string.
    private static String escape(String value) {
        StringBuilder sb = new StringBuilder();
        for (char c : value.toCharArray()) {
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        return sb.toString();
    }
}

