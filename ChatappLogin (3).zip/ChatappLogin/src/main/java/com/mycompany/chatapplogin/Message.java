package com.mycompany.chatapplogin;
 
import java.util.Random;
 
/**
 * Message class for QuickChat (PoE Parts 2 and 3).
 * One Message object is one message; the arrays live in StoredMessages.
 */
public class Message {
 
    public static final int MAX_LENGTH = 250;
 
    private static final Random RANDOM = new Random();
 
    private final String messageID;
    private final int messageNumber;   // "Num messages sent": starts at 0 and goes up by one per message
    private final String recipient;
    private final String text;
 
    public Message(String messageID, int messageNumber, String recipient, String text) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.text = text;
    }
 
    // ---------- Static helpers ----------
 
    // Randomly generates a ten-digit message ID.
    public static String generateMessageID() {
        long number = (long) (RANDOM.nextDouble() * 10_000_000_000L);
        return String.format("%010d", number);
    }
 
    // Checks the message length (max 250 characters) and returns the required messaging.
    public static String checkMessageLength(String message) {
        int length = message == null ? 0 : message.length();
        if (length <= MAX_LENGTH) {
            return "Message ready to send.";
        }
        return "Message exceeds 250 characters by " + (length - MAX_LENGTH) + "; please reduce the size.";
    }
 
    // Recipient rule (reuses the Part 1 cell number check) with the required messaging.
    public static String checkRecipientCell(String recipient) {
        if (ChatappLogin.isValidCellNumber(recipient)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }
 
    // Returns all messages sent while the program is running.
    public static String printMessages() {
        String report = StoredMessages.report(StoredMessages.SENT);
        return report.isEmpty() ? "No messages have been sent." : report;
    }
 
    // Returns the total number of messages sent.
    public static int returnTotalMessages() {
        return StoredMessages.totalSent();
    }
 
    // Test helpers
    public static void clearMessages() {
        StoredMessages.clear();
    }
 
    public static void setStorageFile(java.nio.file.Path file) {
        StoredMessages.setStorageFile(file);
    }
 
    //  Instance methods  
 
    // Message ID must be no more than ten characters (and numeric).
    public boolean checkMessageID() {
        return messageID != null && !messageID.isEmpty()
                && messageID.length() <= 10 && messageID.matches("\\d+");
    }
 
    public String getMessageIDMessage() {
        return "Message ID generated: " + messageID;
    }
 
    public String checkRecipientCell() {
        return checkRecipientCell(recipient);
    }
 
    // First two digits of the ID : message number : first and last word, in capitals.
    public String createMessageHash() {
        String[] words = text == null ? new String[]{""} : text.trim().split("\\s+");
        String first = clean(words[0]);
        String last = clean(words[words.length - 1]);
        String prefix = messageID.length() >= 2 ? messageID.substring(0, 2) : messageID;
        return (prefix + ":" + messageNumber + ":" + first + last).toUpperCase();
    }
 
    // Handles the user's choice: 1 = send, 2 = disregard, 3 = store.
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                StoredMessages.addMessage(messageID, createMessageHash(), recipient, text, StoredMessages.SENT);
                return "Message successfully sent.";
            case 2:
                StoredMessages.addMessage(messageID, createMessageHash(), recipient, text, StoredMessages.DISREGARD);
                return "Press 0 to delete the message.";
            case 3:
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option; please choose 1, 2 or 3.";
        }
    }
 
    // Full details in the required order: Message ID, Message Hash, Recipient, Message.
    public String printMessage() {
        return "Message ID: " + messageID + "\n"
                + "Message Hash: " + createMessageHash() + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + text;
    }
 
    // Adds the message to the stored array and saves all stored messages to the JSON file.
    public boolean storeMessage() {
        StoredMessages.addMessage(messageID, createMessageHash(), recipient, text, StoredMessages.STORED);
        return StoredMessages.saveStoredMessages();
    }
 
    // Removes everything except letters and digits (so "tonight?" becomes "tonight").
    private static String clean(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }
}

