package com.mycompany.chatapplogin;
 
import java.util.Scanner;
 
/**
 * Console runner: registration and login (Part 1), then QuickChat messaging (Part 2).
 * Console only, no GUI.
 */
public class ChatApp {
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
 
        ChatappLogin user = register(scanner);
        login(scanner, user);          // only returns once the user has logged in successfully
        runQuickChat(scanner, user.getFullName());
 
        scanner.close();
    }
 
    // ---------- Part 1: registration ----------
    private static ChatappLogin register(Scanner scanner) {
        System.out.println("=== Chat App: Registration ===");
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine().trim();
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine().trim();
 
        String username;
        ChatappLogin check;
        do {
            System.out.print("Enter a username (underscore, max 5 characters): ");
            username = scanner.nextLine().trim();
            check = new ChatappLogin(firstName, lastName, username, "", "");
            System.out.println(check.getUsernameMessage());
        } while (!check.checkUserName());
 
        String password;
        do {
            System.out.print("Enter a password: ");
            password = scanner.nextLine();
            check = new ChatappLogin(firstName, lastName, username, password, "");
            System.out.println(check.getPasswordMessage());
        } while (!check.checkPasswordComplexity());
 
        String cell;
        do {
            System.out.print("Enter your cell phone number (e.g. +27831234567): ");
            cell = scanner.nextLine().trim();
            check = new ChatappLogin(firstName, lastName, username, password, cell);
            System.out.println(check.getCellPhoneMessage());
        } while (!check.checkCellPhoneNumber());
 
        ChatappLogin user = new ChatappLogin(firstName, lastName, username, password, cell);
        System.out.println(user.registerUser());
        return user;
    }
 
    // ---------- Part 1: login ----------
    private static void login(Scanner scanner, ChatappLogin user) {
        System.out.println("\n=== Chat App: Login ===");
        boolean loggedIn;
        do {
            System.out.print("Username: ");
            String enteredUser = scanner.nextLine().trim();
            System.out.print("Password: ");
            String enteredPass = scanner.nextLine();
            loggedIn = user.loginUser(enteredUser, enteredPass);
            System.out.println(user.returnLoginStatus(loggedIn));
        } while (!loggedIn);
    }
 
    // ---------- Part 2: QuickChat ----------
    private static void runQuickChat(Scanner scanner, String senderName) {
        System.out.println("\nWelcome to QuickChat.");
 
        // Read any messages stored in earlier sessions from the JSON file into the stored array.
        int loaded = StoredMessages.loadStoredMessages();
        if (loaded > 0) {
            System.out.println(loaded + " stored message(s) loaded from the JSON file.");
        }
 
        int limit = readInt(scanner, "How many messages do you wish to enter? ", 1, Integer.MAX_VALUE);
        int entered = 0;
        int choice;
 
        do {
            System.out.println("\nPlease choose an option:");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            choice = readInt(scanner, "Option: ", 1, 4);
 
            switch (choice) {
                case 1:
                    if (entered >= limit) {
                        System.out.println("You have already entered all " + limit + " messages.");
                    } else {
                        while (entered < limit) {
                            System.out.println("\n--- Message " + (entered + 1) + " of " + limit + " ---");
                            composeMessage(scanner, entered);
                            entered++;
                        }
                        System.out.println("\nTotal number of messages sent: " + Message.returnTotalMessages());
                    }
                    break;
                case 2:
                    System.out.println("\n" + Message.printMessages());
                    break;
                case 4:
                    storedMessagesMenu(scanner, senderName);
                    break;
                default:
                    System.out.println("Total number of messages sent: " + Message.returnTotalMessages());
                    System.out.println("Goodbye.");
            }
        } while (choice != 3);
    }
 
    // ---------- Part 3: Stored Messages ----------
    private static void storedMessagesMenu(Scanner scanner, String senderName) {
        int choice;
        do {
            System.out.println("\n--- Stored Messages ---");
            System.out.println("1) Display the sender and recipient of all stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message ID");
            System.out.println("4) Search for all messages sent or stored for a recipient");
            System.out.println("5) Delete a message using its message hash");
            System.out.println("6) Display a report of all stored messages");
            System.out.println("0) Back to the main menu");
            choice = readInt(scanner, "Option: ", 0, 6);
 
            switch (choice) {
                case 1:
                    System.out.println(StoredMessages.displayStoredSenderAndRecipient(senderName));
                    break;
                case 2:
                    System.out.println(StoredMessages.longestStoredMessage());
                    break;
                case 3:
                    System.out.print("Enter the message ID: ");
                    System.out.println(StoredMessages.searchByMessageID(scanner.nextLine().trim()));
                    break;
                case 4:
                    System.out.print("Enter the recipient's cell number: ");
                    java.util.List<String> found = StoredMessages.searchByRecipient(scanner.nextLine().trim());
                    if (found.isEmpty()) {
                        System.out.println("No messages found for that recipient.");
                    }
                    for (String text : found) {
                        System.out.println(text);
                    }
                    break;
                case 5:
                    System.out.print("Enter the message hash: ");
                    System.out.println(StoredMessages.deleteByHash(scanner.nextLine()));
                    break;
                case 6:
                    String report = StoredMessages.report(StoredMessages.STORED);
                    System.out.println(report.isEmpty() ? "There are no stored messages." : report);
                    break;
                default:
                    break;
            }
        } while (choice != 0);
    }
 
    private static void composeMessage(Scanner scanner, int messageNumber) {
        // Recipient
        String recipient;
        boolean validRecipient;
        do {
            System.out.print("Enter the recipient's cell number (e.g. +27718693002): ");
            recipient = scanner.nextLine().trim();
            System.out.println(Message.checkRecipientCell(recipient));
            validRecipient = ChatappLogin.isValidCellNumber(recipient);
        } while (!validRecipient);
 
        // Message text (max 250 characters)
        String text;
        boolean validText;
        do {
            System.out.print("Enter your message: ");
            text = scanner.nextLine().trim();
            validText = !text.isEmpty() && text.length() <= Message.MAX_LENGTH;
            if (text.isEmpty()) {
                System.out.println("A message cannot be empty.");
            } else if (!validText) {
                System.out.println(Message.checkMessageLength(text));
                System.out.println("Please enter a message of less than 250 characters.");
            }
        } while (!validText);
        System.out.println(Message.checkMessageLength(text));
 
        // Build the message and show its generated ID
        Message message = new Message(Message.generateMessageID(), messageNumber, recipient, text);
        System.out.println(message.getMessageIDMessage());
 
        // Send / disregard / store
        System.out.println("What would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        int option = readInt(scanner, "Option: ", 1, 3);
        System.out.println(message.SentMessage(option));
 
        if (option == 1) {
            System.out.println("\n" + message.printMessage());
        } else if (option == 2) {
            String answer;
            do {
                System.out.print("Enter 0: ");
                answer = scanner.nextLine().trim();
            } while (!answer.equals("0"));
            System.out.println("Message deleted.");
        }
    }
 
    // Reads a whole number in the range [min, max], asking again until valid.
    private static int readInt(Scanner scanner, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String line = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException e) {
                // fall through to the error message
            }
            System.out.println("Please enter a valid number.");
        }
    }
}
    

