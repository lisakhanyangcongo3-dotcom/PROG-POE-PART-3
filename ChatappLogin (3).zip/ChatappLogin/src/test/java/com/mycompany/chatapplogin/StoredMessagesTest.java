/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapplogin;
 
import static org.junit.jupiter.api.Assertions.*;
 
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
 
public class StoredMessagesTest {
 
    @TempDir
    Path tempDir;
 
    private Message message1, message2, message3, message4, message5;
 
   
    @BeforeEach
    public void setUp() {
        Message.clearMessages();
        Message.setStorageFile(tempDir.resolve("messages.json"));
 
        message1 = new Message("1000000001", 0, "+27834557896", "Did you get the cake?");
        message2 = new Message("2000000002", 1, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
        message3 = new Message("3000000003", 2, "+27834484567", "Yohoooo, I am at your gate.");
        message4 = new Message("4000000004", 3, "0838884567", "It is dinner time!");
        message5 = new Message("5000000005", 4, "+27838884567", "Ok, I am leaving without you.");
 
        message1.SentMessage(1);   // Sent
        message2.SentMessage(3);   // Stored
        message3.SentMessage(2);   // Disregard
        message4.SentMessage(1);   // Sent
        message5.SentMessage(3);   // Stored
    }
 
   
    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals(List.of("Did you get the cake?", "It is dinner time!"), StoredMessages.getSentMessages());
    }
 
    @Test
    public void testDisregardedMessagesArrayPopulated() {
        assertEquals(List.of("Yohoooo, I am at your gate."), StoredMessages.getDisregardedMessages());
    }
 
    @Test
    public void testStoredMessagesArrayPopulated() {
        assertEquals(List.of("Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."), StoredMessages.getStoredMessages());
    }
 
    @Test
    public void testMessageIDAndHashArraysPopulated() {
        assertEquals(List.of("1000000001", "2000000002", "3000000003", "4000000004", "5000000005"),
                StoredMessages.getMessageIDs());
        assertEquals(List.of("10:0:DIDCAKE", "20:1:WHERETIME", "30:2:YOHOOOOGATE", "40:3:ITTIME", "50:4:OKYOU"),
                StoredMessages.getMessageHashes());
    }
 
    // Display the longest message 
    @Test
    public void testLongestStoredMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.", StoredMessages.longestStoredMessage());
    }
 
    //  Search for message ID 
    @Test
    public void testSearchByMessageID() {
        assertEquals("Recipient: 0838884567, Message: It is dinner time!", StoredMessages.searchByMessageID("4000000004"));
    }
 
    @Test
    public void testSearchByMessageIDNotFound() {
        assertEquals("Message ID not found.", StoredMessages.searchByMessageID("0000000000"));
    }
 
    //  Search all messages sent or stored for a recipient 
    @Test
    public void testSearchByRecipient() {
        assertEquals(List.of("Where are you? You are late! I have asked you to be on time.", "Ok, I am leaving without you."),
                StoredMessages.searchByRecipient("+27838884567"));
    }
 
    @Test
    public void testSearchByRecipientIgnoresDisregarded() {
        assertTrue(StoredMessages.searchByRecipient("+27834484567").isEmpty());
    }
 
    // Delete a message using the message hash 
    @Test
    public void testDeleteMessageByHash() {
        String result = StoredMessages.deleteByHash(message2.createMessageHash());
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", result);
        assertEquals(List.of("Ok, I am leaving without you."), StoredMessages.getStoredMessages());
        assertEquals(4, StoredMessages.getMessageHashes().size());
    }
 
    @Test
    public void testDeleteUpdatesJsonFile() throws IOException {
        StoredMessages.deleteByHash("20:1:WHERETIME");
        String json = Files.readString(tempDir.resolve("messages.json"), StandardCharsets.UTF_8);
        assertFalse(json.contains("WHERETIME"));
        assertTrue(json.contains("OKYOU"));
    }
 
    @Test
    public void testDeleteHashNotFound() {
        assertEquals("Message hash not found.", StoredMessages.deleteByHash("00:0:NOPE"));
    }
 
    //  Display report 
    @Test
    public void testSentReportShowsHashRecipientAndMessage() {
        String report = StoredMessages.report(StoredMessages.SENT);
        assertTrue(report.contains("Message Hash: 10:0:DIDCAKE"));
        assertTrue(report.contains("Recipient: +27834557896"));
        assertTrue(report.contains("Message: Did you get the cake?"));
        assertTrue(report.contains("Message Hash: 40:3:ITTIME"));
        assertFalse(report.contains("Yohoooo"));
    }
 
    @Test
    public void testStoredReportShowsFullDetails() {
        String report = StoredMessages.report(StoredMessages.STORED);
        assertTrue(report.contains("Message ID: 2000000002"));
        assertTrue(report.contains("Message Hash: 20:1:WHERETIME"));
        assertTrue(report.contains("Recipient: +27838884567"));
        assertTrue(report.contains("Message: Ok, I am leaving without you."));
        assertFalse(report.contains("cake"));
    }
 
    @Test
    public void testSenderAndRecipientOfStoredMessages() {
        assertEquals("Sender: Kyle Smith | Recipient: +27838884567\nSender: Kyle Smith | Recipient: +27838884567",
                StoredMessages.displayStoredSenderAndRecipient("Kyle Smith"));
    }
 
    //  Read the JSON file into an array 
    @Test
    public void testReadJsonFileIntoStoredArray() {
        StoredMessages.clear();   // empties the arrays in memory, the file stays on disk
        assertTrue(StoredMessages.getStoredMessages().isEmpty());
 
        int loaded = StoredMessages.loadStoredMessages();
 
        assertEquals(2, loaded);
        assertEquals(List.of("Where are you? You are late! I have asked you to be on time.", "Ok, I am leaving without you."),
                StoredMessages.getStoredMessages());
        assertEquals(List.of("20:1:WHERETIME", "50:4:OKYOU"), StoredMessages.getMessageHashes());
    }
 
    @Test
    public void testJsonRoundTripKeepsSpecialCharacters() {
        Message tricky = new Message("6000000006", 5, "+27831112222", "She said \"hi\" \\ then left");
        tricky.SentMessage(3);
        StoredMessages.clear();
        StoredMessages.loadStoredMessages();
        assertTrue(StoredMessages.getStoredMessages().contains("She said \"hi\" \\ then left"));
    }
}
